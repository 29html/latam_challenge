from typing import List, Tuple

def q3_memory(file_path: str) -> List[Tuple[str, int]]:
    pass