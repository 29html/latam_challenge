from typing import List, Tuple

def q2_memory(file_path: str) -> List[Tuple[str, int]]:
    pass