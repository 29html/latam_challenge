from typing import List, Tuple

def q2_time(file_path: str) -> List[Tuple[str, int]]:
    pass